
# Copyright (c) 2025 devgagan : https://github.com/devgaganin.
# Licensed under the GNU General Public License v3.0.
# See LICENSE file in the repository root for full license text.

# Config values directly set here

# VPS --- FILL COOKIES 🍪 in """ ... """

INST_COOKIES = """
# write up here insta cookies
"""

YTUB_COOKIES = """
# write here yt cookies
"""

API_ID = 23939637
API_HASH = "477f51720ede3eef6997dbc442151c43"
BOT_TOKEN = "7244991864:AAFvlqa0p_j14EdZjneaNceAPISTM_5se_8"
MONGO_DB = "mongodb+srv://rex380895:sxz1J690QyA5RIaj@cluster0.scyfy8x.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0"
OWNER_ID = [6425525488]
DB_NAME = "telegram_downloader"
STRING = None  # optional
LOG_GROUP = -4686512840  # optional with -100
FORCE_SUB = -1002439642259  # optional with -100
MASTER_KEY = "gK8HzLfT9QpViJcYeB5wRa3DmN7P2xUq"  # for session encryption
IV_KEY = "s7Yx5CpVmE3F"  # for decryption
YT_COOKIES = YTUB_COOKIES
INSTA_COOKIES = INST_COOKIES
FREEMIUM_LIMIT = 0
PREMIUM_LIMIT = 500
JOIN_LINK = "https://t.me/team_spy_pro"  # this link for start command message
ADMIN_CONTACT = "https://t.me/username_of_admin"
